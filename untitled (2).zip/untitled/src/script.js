// Example project data

const projects = [

  { name: "Portfolio Website", description: "A personal portfolio built with HTML, CSS, and JS." },

  { name: "Calculator App", description: "A simple calculator using JavaScript." },

  { name: "To-Do List", description: "A task manager built with JS." }

];

// Display projects dynamically

const projectList = document.getElementById("projectList");

projects.forEach(project => {

  const li = document.createElement("li");

  li.innerHTML = `<strong>${project.name}</strong>: ${project.description}`;

  projectList.appendChild(li);

});

// Show/hide sections

function showSection(sectionId) {

  document.querySelectorAll(".content").forEach(section => {

    section.classList.remove("active");

    section.classList.add("hidden");

  });

  document.getElementById(sectionId).classList.add("active");

  document.getElementById(sectionId).classList.remove("hidden");

}

// Show About section by default

showSection("about");